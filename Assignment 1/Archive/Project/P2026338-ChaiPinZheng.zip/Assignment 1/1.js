ax.set_title("Distribution of Doctors in varying sectors", y = 1.08, fontsize = 17)
